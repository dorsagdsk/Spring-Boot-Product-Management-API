INSERT INTO product
(id, name, desc, brand, price, category, release_date, available, quantity)
VALUES
    (1, 'Laptop', 'Gaming laptop', 'Asus', 1200.50, 'Electronics', '2025-01-15', TRUE, 10),
    (2, 'Smartphone', 'Android smartphone', 'Samsung', 799.99, 'Electronics', '2025-03-20', TRUE, 25),
    (3, 'Headphones', 'Wireless headphones', 'Sony', 149.99, 'Accessories', '2025-02-10', TRUE, 15),
    (4, 'Keyboard', 'Mechanical keyboard', 'Logitech', 89.50, 'Accessories', '2024-11-05', TRUE, 20),
    (5, 'Monitor', '27-inch 4K monitor', 'LG', 399.99, 'Electronics', '2025-04-12', FALSE, 0);