package com.dorsa.ecom.proj.controller;

import com.dorsa.ecom.proj.model.Product;
import com.dorsa.ecom.proj.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/api")

public class ProductController {
    @Autowired
    private ProductService service;


    @RequestMapping("/")
    public String great() {
        return "hello";
    }

    @GetMapping("/products")
    public ResponseEntity<List<Product>> getAllProduct() {
        return new ResponseEntity<>(service.getAllProduct(), HttpStatus.OK);
    }

    @GetMapping("/product/{id}")
    public ResponseEntity<Product> getProduct(@PathVariable int id) {
        Product product = service.getProduct(id);

        if (product != null) {
            return new ResponseEntity<>(product, HttpStatus.OK);

        } else
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);


    }

    @PostMapping("/product")
    public ResponseEntity<?> addProduct(@RequestPart Product product,
                                        @RequestPart MultipartFile imageFile) {

        try {
            Product product1 = service.addProduct(product, imageFile);
            return new ResponseEntity<>(product1, HttpStatus.CREATED);

        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/product/{productId}/image")
    public ResponseEntity<byte[]> getImageProductId(@PathVariable int productId) {

        Product product1 = service.getProduct(productId);
        byte[] imageFile = product1.getImageDate();

        return ResponseEntity.ok()
                .contentType(MediaType.valueOf(product1.getImageType())).body(imageFile);

    }

    @PutMapping("/product/{productId}")
    public ResponseEntity<String> updateProduct(
            @PathVariable int productId,
            @RequestPart Product product,
            @RequestPart MultipartFile imageFile) {

        Product product1 = null;
        try {
            product1 = service.updatePro(productId, product, imageFile);
        } catch (IOException e) {
            return new ResponseEntity<>("Failed to Update",
                    HttpStatus.BAD_REQUEST);
        }
        if (product1 != null) {
            return new ResponseEntity<>("Updated", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Failed to Update",
                    HttpStatus.BAD_REQUEST);
        }
    }

    @DeleteMapping("/product/{id}")
    public ResponseEntity<String> deleteProduct(@PathVariable int id){
        Product product= service.getProduct(id);


        if (product != null) {
            service.deleteProduct(id);
            return new ResponseEntity<>("Deleted", HttpStatus.OK);

        } else
            return new ResponseEntity<>("Product not found",HttpStatus.NOT_FOUND);


    }
    @GetMapping("/products/search")
    public ResponseEntity<List<Product>> searchProduct(@RequestParam String keyword){
        List<Product> products =service.searchProduct(keyword);
        return new  ResponseEntity<>(products,HttpStatus.OK);
    }


}

